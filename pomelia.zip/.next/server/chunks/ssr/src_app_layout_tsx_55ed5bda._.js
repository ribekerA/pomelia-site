module.exports = {

"[project]/src/app/layout.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "metadata": ()=>metadata
});
const metadata = {
    title: "Pomélia | Spitz Alemão Anão & Lulu da Pomerânia Premium",
    description: "Filhotes de Spitz Alemão Anão e Lulu da Pomerânia com pedigree, entrega nacional, suporte vitalício e excelência reconhecida. Reserve já seu filhote Pomélia!",
    robots: "index, follow",
    openGraph: {
        title: "Pomélia | Spitz Alemão Anão & Lulu da Pomerânia Premium",
        description: "Filhotes de Spitz Alemão Anão e Lulu da Pomerânia com pedigree, entrega nacional, suporte vitalício e excelência reconhecida. Reserve já seu filhote Pomélia!",
        url: "https://pomelia.com.br/",
        images: [
            {
                url: "https://pomelia.com.br/images/og-hero.webp",
                width: 1200,
                height: 630,
                alt: "Pomélia Spitz Alemão Anão & Lulu da Pomerânia"
            }
        ],
        site_name: "Pomélia",
        locale: "pt_BR",
        type: "website"
    },
    twitter: {
        card: "summary_large_image",
        site: "@pomelia.oficial",
        title: "Pomélia | Spitz Alemão Anão & Lulu da Pomerânia Premium",
        description: "Filhotes de Spitz Alemão Anão e Lulu da Pomerânia com pedigree, entrega nacional, suporte vitalício e excelência reconhecida. Reserve já seu filhote Pomélia!",
        image: "https://pomelia.com.br/images/og-hero.webp"
    }
};
}),

};

//# sourceMappingURL=src_app_layout_tsx_55ed5bda._.js.map
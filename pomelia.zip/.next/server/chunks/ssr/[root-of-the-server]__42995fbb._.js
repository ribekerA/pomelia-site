module.exports = {

"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/components/Depoimentos.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/app/components/Depoimentos.tsx
__turbopack_context__.s({
    "default": ()=>Depoimentos
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const depoimentos = [
    {
        img: "/images/clientes/cliente1.jpg",
        texto: "A Pomélia mudou nossa rotina! O filhote chegou super saudável, cheio de energia e carinho. Atendimento nota 1000!",
        nome: "Patrícia – Campinas/SP"
    },
    {
        img: "/images/clientes/cliente2.jpg",
        texto: "Atendimento humano, entrega rápida e muito carinho em cada detalhe. Recomendo para quem quer exclusividade.",
        nome: "André – São Paulo/SP"
    },
    {
        img: "/images/clientes/cliente3.jpg",
        texto: "Tive suporte desde o início, até depois da entrega. Meu Spitz está lindo, saudável e super adaptado. Gratidão!",
        nome: "Juliana – Sorocaba/SP"
    },
    {
        img: "/images/clientes/cliente4.jpg",
        texto: "O processo foi todo transparente, recebi fotos e vídeos diários. Meu Lulu é um verdadeiro sonho.",
        nome: "Renata – Belo Horizonte/MG"
    },
    {
        img: "/images/clientes/cliente5.jpg",
        texto: "Achei que nunca teria um Spitz premium. Com a Pomélia realizei meu sonho, recomendo de olhos fechados.",
        nome: "Leonardo – Rio de Janeiro/RJ"
    },
    {
        img: "/images/clientes/cliente6.jpg",
        texto: "A equipe é sensacional! Me deram segurança, suporte e o filhote já chegou socializado.",
        nome: "Camila – Ribeirão Preto/SP"
    },
    {
        img: "/images/clientes/cliente7.jpg",
        texto: "Só tenho elogios! Contrato digital, pedigree, fotos dos pais... Muito melhor do que esperava.",
        nome: "Amanda – Santos/SP"
    },
    {
        img: "/images/clientes/cliente8.jpg",
        texto: "Vale cada centavo. Atendimento diferenciado e entrega com todo o suporte pós-venda.",
        nome: "Rodrigo – Brasília/DF"
    },
    {
        img: "/images/clientes/cliente9.jpg",
        texto: "A Pomélia superou minhas expectativas. Fui muito bem tratada e recebi dicas valiosas!",
        nome: "Tatiane – Salvador/BA"
    },
    {
        img: "/images/clientes/cliente10.jpg",
        texto: "Recomendo de olhos fechados. Responsabilidade, carinho e confiança definem.",
        nome: "Rafael – Curitiba/PR"
    },
    {
        img: "/images/clientes/cliente11.jpg",
        texto: "Recebi acompanhamento em todo o processo, fiquei super segura na compra!",
        nome: "Gabriela – Florianópolis/SC"
    },
    {
        img: "/images/clientes/cliente12.jpg",
        texto: "O filhote chegou perfeito e a família está apaixonada. Pomélia é referência!",
        nome: "Bianca – Porto Alegre/RS"
    }
];
function Depoimentos() {
    const [atual, setAtual] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const intervalo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Define quantos depoimentos por tela
    function getQtdPorTela() {
        if ("TURBOPACK compile-time truthy", 1) return 1;
        //TURBOPACK unreachable
        ;
    }
    const [porTela, setPorTela] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(getQtdPorTela());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleResize = ()=>setPorTela(getQtdPorTela());
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    // Auto-scroll
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        intervalo.current = setInterval(()=>{
            setAtual((a)=>(a + porTela) % depoimentos.length);
        }, 5000);
        return ()=>intervalo.current && clearInterval(intervalo.current);
    }, [
        porTela
    ]);
    // Exibe só os depoimentos visíveis
    const visiveis = [];
    for(let i = 0; i < porTela; i++){
        visiveis.push(depoimentos[(atual + i) % depoimentos.length]);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-16 px-4 bg-[#F5F1EB] border-t border-primary/10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl md:text-4xl font-bold text-primary text-center mb-8",
                children: "O que dizem nossos clientes"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Depoimentos.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-6 overflow-hidden max-w-5xl mx-auto",
                children: visiveis.map((dep, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full max-w-xs flex-shrink-0 bg-white rounded-3xl shadow-xl border border-primary/10 overflow-hidden transition-transform duration-700",
                        style: {
                            minHeight: 370
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: dep.img,
                                alt: `Depoimento de ${dep.nome}`,
                                className: "w-full h-56 object-cover object-center",
                                loading: "lazy"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Depoimentos.tsx",
                                lineNumber: 115,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6 flex flex-col h-[120px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-800 text-base italic mb-4",
                                        children: [
                                            '"',
                                            dep.texto,
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Depoimentos.tsx",
                                        lineNumber: 122,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-bold text-primary text-sm mt-auto",
                                        children: dep.nome
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Depoimentos.tsx",
                                        lineNumber: 123,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Depoimentos.tsx",
                                lineNumber: 121,
                                columnNumber: 13
                            }, this)
                        ]
                    }, idx, true, {
                        fileName: "[project]/src/app/components/Depoimentos.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/components/Depoimentos.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center text-sm text-gray-400 mt-6",
                children: "Mais de 500 famílias satisfeitas em todo Brasil."
            }, void 0, false, {
                fileName: "[project]/src/app/components/Depoimentos.tsx",
                lineNumber: 128,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Depoimentos.tsx",
        lineNumber: 104,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/app/components/FAQ.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/app/components/Faq.tsx
__turbopack_context__.s({
    "default": ()=>Faq
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
const faqs = [
    {
        question: "A Pomélia é canil ou criatório?",
        answer: "Somos um criatório familiar focado em exclusividade, bem-estar e acompanhamento individual dos filhotes. Não trabalhamos como canil comercial."
    },
    {
        question: "Como funciona a entrega dos filhotes?",
        answer: "Entregamos em todo o Brasil com transporte especializado e seguro. O filhote vai até você com acompanhamento e garantia total."
    },
    {
        question: "Os filhotes têm pedigree e vacinas?",
        answer: "Sim! Todos filhotes Pomélia têm pedigree CBKC, vacinas em dia, vermifugados, microchipados e com atestado veterinário."
    },
    {
        question: "Qual o suporte após a compra?",
        answer: "Você recebe suporte vitalício no WhatsApp e acompanhamento pós-venda para todas as dúvidas sobre saúde, adaptação e cuidados."
    },
    {
        question: "Posso visitar ou conhecer os pais dos filhotes?",
        answer: "Por questões de biossegurança, priorizamos atendimento online, mas enviamos fotos, vídeos e fazemos videochamadas dos filhotes e dos pais."
    },
    {
        question: "Como faço a reserva do meu filhote?",
        answer: "Basta preencher o formulário ou clicar no WhatsApp para atendimento. As reservas são realizadas por ordem de contato e análise do perfil do tutor."
    }
];
function Faq() {
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "max-w-3xl mx-auto py-16 px-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl md:text-4xl font-bold text-primary text-center mb-10",
                children: "Perguntas Frequentes"
            }, void 0, false, {
                fileName: "[project]/src/app/components/FAQ.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "space-y-4",
                children: faqs.map((faq, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: "bg-white rounded-2xl shadow-lg border border-primary/10 transition-all",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "w-full flex items-center justify-between px-6 py-4 text-lg md:text-xl font-semibold text-left text-primary focus:outline-none",
                                onClick: ()=>setOpen(open === i ? null : i),
                                "aria-expanded": open === i,
                                children: [
                                    faq.question,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `ml-2 transform transition-transform ${open === i ? "rotate-90" : ""}`,
                                        children: "▶"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/FAQ.tsx",
                                        lineNumber: 55,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/FAQ.tsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `overflow-hidden transition-all px-6 ${open === i ? "max-h-40 py-2" : "max-h-0"}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-700 text-base",
                                    children: faq.answer
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/FAQ.tsx",
                                    lineNumber: 64,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/FAQ.tsx",
                                lineNumber: 59,
                                columnNumber: 13
                            }, this)
                        ]
                    }, i, true, {
                        fileName: "[project]/src/app/components/FAQ.tsx",
                        lineNumber: 48,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/components/FAQ.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/FAQ.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__42995fbb._.js.map
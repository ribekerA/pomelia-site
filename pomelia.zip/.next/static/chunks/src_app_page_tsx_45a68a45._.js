(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f15437d0._.js",
  "static/chunks/src_components_form_LeadForm_tsx_fc4f22fb._.js"
],
    source: "dynamic"
});

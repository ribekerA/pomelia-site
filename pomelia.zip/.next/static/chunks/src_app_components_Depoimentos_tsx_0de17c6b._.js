(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/components/Depoimentos.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// src/app/components/Depoimentos.tsx
__turbopack_context__.s({
    "default": ()=>Depoimentos
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const depoimentos = [
    {
        img: "/images/clientes/cliente1.jpg",
        texto: "A Pomélia mudou nossa rotina! O filhote chegou super saudável, cheio de energia e carinho. Atendimento nota 1000!",
        nome: "Patrícia – Campinas/SP"
    },
    {
        img: "/images/clientes/cliente2.jpg",
        texto: "Atendimento humano, entrega rápida e muito carinho em cada detalhe. Recomendo para quem quer exclusividade.",
        nome: "André – São Paulo/SP"
    },
    {
        img: "/images/clientes/cliente3.jpg",
        texto: "Tive suporte desde o início, até depois da entrega. Meu Spitz está lindo, saudável e super adaptado. Gratidão!",
        nome: "Juliana – Sorocaba/SP"
    },
    {
        img: "/images/clientes/cliente4.jpg",
        texto: "O processo foi todo transparente, recebi fotos e vídeos diários. Meu Lulu é um verdadeiro sonho.",
        nome: "Renata – Belo Horizonte/MG"
    },
    {
        img: "/images/clientes/cliente5.jpg",
        texto: "Achei que nunca teria um Spitz premium. Com a Pomélia realizei meu sonho, recomendo de olhos fechados.",
        nome: "Leonardo – Rio de Janeiro/RJ"
    },
    {
        img: "/images/clientes/cliente6.jpg",
        texto: "A equipe é sensacional! Me deram segurança, suporte e o filhote já chegou socializado.",
        nome: "Camila – Ribeirão Preto/SP"
    },
    {
        img: "/images/clientes/cliente7.jpg",
        texto: "Só tenho elogios! Contrato digital, pedigree, fotos dos pais... Muito melhor do que esperava.",
        nome: "Amanda – Santos/SP"
    },
    {
        img: "/images/clientes/cliente8.jpg",
        texto: "Vale cada centavo. Atendimento diferenciado e entrega com todo o suporte pós-venda.",
        nome: "Rodrigo – Brasília/DF"
    },
    {
        img: "/images/clientes/cliente9.jpg",
        texto: "A Pomélia superou minhas expectativas. Fui muito bem tratada e recebi dicas valiosas!",
        nome: "Tatiane – Salvador/BA"
    },
    {
        img: "/images/clientes/cliente10.jpg",
        texto: "Recomendo de olhos fechados. Responsabilidade, carinho e confiança definem.",
        nome: "Rafael – Curitiba/PR"
    },
    {
        img: "/images/clientes/cliente11.jpg",
        texto: "Recebi acompanhamento em todo o processo, fiquei super segura na compra!",
        nome: "Gabriela – Florianópolis/SC"
    },
    {
        img: "/images/clientes/cliente12.jpg",
        texto: "O filhote chegou perfeito e a família está apaixonada. Pomélia é referência!",
        nome: "Bianca – Porto Alegre/RS"
    }
];
function Depoimentos() {
    _s();
    const [atual, setAtual] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const intervalo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Define quantos depoimentos por tela
    function getQtdPorTela() {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (window.innerWidth >= 1024) return 3;
        if (window.innerWidth >= 640) return 2;
        return 1;
    }
    const [porTela, setPorTela] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(getQtdPorTela());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Depoimentos.useEffect": ()=>{
            const handleResize = {
                "Depoimentos.useEffect.handleResize": ()=>setPorTela(getQtdPorTela())
            }["Depoimentos.useEffect.handleResize"];
            window.addEventListener("resize", handleResize);
            return ({
                "Depoimentos.useEffect": ()=>window.removeEventListener("resize", handleResize)
            })["Depoimentos.useEffect"];
        }
    }["Depoimentos.useEffect"], []);
    // Auto-scroll
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Depoimentos.useEffect": ()=>{
            intervalo.current = setInterval({
                "Depoimentos.useEffect": ()=>{
                    setAtual({
                        "Depoimentos.useEffect": (a)=>(a + porTela) % depoimentos.length
                    }["Depoimentos.useEffect"]);
                }
            }["Depoimentos.useEffect"], 5000);
            return ({
                "Depoimentos.useEffect": ()=>intervalo.current && clearInterval(intervalo.current)
            })["Depoimentos.useEffect"];
        }
    }["Depoimentos.useEffect"], [
        porTela
    ]);
    // Exibe só os depoimentos visíveis
    const visiveis = [];
    for(let i = 0; i < porTela; i++){
        visiveis.push(depoimentos[(atual + i) % depoimentos.length]);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-16 px-4 bg-[#F5F1EB] border-t border-primary/10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-3xl md:text-4xl font-bold text-primary text-center mb-8",
                children: "O que dizem nossos clientes"
            }, void 0, false, {
                fileName: "[project]/src/app/components/Depoimentos.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center gap-6 overflow-hidden max-w-5xl mx-auto",
                children: visiveis.map((dep, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full max-w-xs flex-shrink-0 bg-white rounded-3xl shadow-xl border border-primary/10 overflow-hidden transition-transform duration-700",
                        style: {
                            minHeight: 370
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: dep.img,
                                alt: "Depoimento de ".concat(dep.nome),
                                className: "w-full h-56 object-cover object-center",
                                loading: "lazy"
                            }, void 0, false, {
                                fileName: "[project]/src/app/components/Depoimentos.tsx",
                                lineNumber: 115,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-6 flex flex-col h-[120px]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-800 text-base italic mb-4",
                                        children: [
                                            '"',
                                            dep.texto,
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/components/Depoimentos.tsx",
                                        lineNumber: 122,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-bold text-primary text-sm mt-auto",
                                        children: dep.nome
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Depoimentos.tsx",
                                        lineNumber: 123,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Depoimentos.tsx",
                                lineNumber: 121,
                                columnNumber: 13
                            }, this)
                        ]
                    }, idx, true, {
                        fileName: "[project]/src/app/components/Depoimentos.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/components/Depoimentos.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center text-sm text-gray-400 mt-6",
                children: "Mais de 500 famílias satisfeitas em todo Brasil."
            }, void 0, false, {
                fileName: "[project]/src/app/components/Depoimentos.tsx",
                lineNumber: 128,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/components/Depoimentos.tsx",
        lineNumber: 104,
        columnNumber: 5
    }, this);
}
_s(Depoimentos, "Cf9MSZX60VCj06il4ZsCxIH6enk=");
_c = Depoimentos;
var _c;
__turbopack_context__.k.register(_c, "Depoimentos");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_components_Depoimentos_tsx_0de17c6b._.js.map
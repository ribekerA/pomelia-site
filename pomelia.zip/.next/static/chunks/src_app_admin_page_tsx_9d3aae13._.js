(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_b1ac0bb2.js",
  "static/chunks/node_modules_bb59eeda._.js",
  "static/chunks/src_c5534f75._.js"
],
    source: "dynamic"
});

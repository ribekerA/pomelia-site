(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_motion-dom_dist_es_ed5d7820._.js",
  "static/chunks/node_modules_framer-motion_dist_es_c4413217._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_next_146adb41._.js",
  "static/chunks/node_modules_motion-utils_dist_es_32ac5814._.js",
  "static/chunks/src_app_components_1b145f82._.js"
],
    source: "dynamic"
});

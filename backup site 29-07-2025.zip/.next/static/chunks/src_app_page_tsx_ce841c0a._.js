(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_30ef7369._.js",
  "static/chunks/src_components_LeadForm_tsx_b6a23428._.js"
],
    source: "dynamic"
});

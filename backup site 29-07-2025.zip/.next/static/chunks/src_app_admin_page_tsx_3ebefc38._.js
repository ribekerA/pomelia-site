(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_node-fetch_browser_b1ac0bb2.js",
  "static/chunks/node_modules_0d59872c._.js",
  "static/chunks/src_d14b3094._.js"
],
    source: "dynamic"
});
